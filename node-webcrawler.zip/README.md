﻿# node-webcrawler(魔改)

### 使用方法
```shell
npm install
node index.js
```
按照控制台的提示进行操作即可

### 特性
- 添加配置进行界面化，不需要手动更改代码
- 类似jQuery的选择器易于书写 

更多介绍：http://www.xiaoboy.com/detail/2015030617.html
